package Barco
class Barca {

  /*
   * El Pasajero id quiere darse una vuelta en la barca desde la orilla pos
   */
  @throws[InterruptedException]
  def subir(id: Int, pos: Int): Unit = {
    // TODO
  }

  /*
   * Cuando el viaje ha terminado, el Pasajero que está en la barca se baja
   */
  @throws[InterruptedException]
  def bajar(id: Int): Int = {
    // TODO
    0 // valor de retorno ficticio
  }

  /*
   * El Capitán espera hasta que se suben 3 pasajeros para comenzar el viaje
   */
  @throws[InterruptedException]
  def esperoSuban(): Unit = {
    // TODO
  }

  /*
   * El Capitán indica a los pasajeros que el viaje ha terminado y tienen que bajarse
   */
  @throws[InterruptedException]
  def finViaje(): Unit = {
    // TODO
  }

}
