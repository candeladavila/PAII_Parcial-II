import java.util.concurrent._

class GestorAgua {

  def hListo(id: Int): Unit = {
  }

  def oListo(id: Int): Unit = {
  }
}
