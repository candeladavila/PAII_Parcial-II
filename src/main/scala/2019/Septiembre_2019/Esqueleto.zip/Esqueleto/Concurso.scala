class Concurso {

  @throws[InterruptedException]
  def tirarMoneda(id: Int, cara: Boolean): Unit = {
    // TODO
  }

  def concursoTerminado(): Boolean = {
    false // TODO: borrar
  }
}
