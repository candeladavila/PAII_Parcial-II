class Tiovivo(capacidad: Int) {

  def subir(id: Int): Unit = {
    // TODO
  }

  def bajar(id: Int): Unit = {
    // TODO
  }

  def esperaLleno(): Unit = {
    // TODO
  }

  def finViaje(): Unit = {
    // TODO
  }
}
